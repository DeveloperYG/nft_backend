var mysql = require('mysql');
const axios = require("axios");
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "nftweb",
    multipleStatements: true,
  });

  con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
  });

//   var sql = "SELECT COUNT(*) FROM nft_collections";
  
//   con.query(sql, (error, results) => {
//     if (error) {
//       // console.log(error);
      
//     }  else {

//         var a=((results[0]['COUNT(*)'])/100).toFixed(0)
//         // console.log(a);
//         for(i=1;i<=a;i++)
//         {
//         const v=i;
//         // console.log('a',v);
//         const b=(v-1)*100;
//         const c=v*100;
//         // console.log(` a ${b}-${c}`)
//         setTimeout(()=>{
//             console.log('b',v);
//             // console.log(` b ${b}-${c}`)
//             var sql1 = `SELECT id,name,slug,logo FROM nft_collections LIMIT ${b},100`;
//                 con.query(sql1, function (err, result) {
//                     if (err) throw err;
//                     result.forEach(async (item)=>{
//                       // console.log(b)
//                         console.log(item.id)
//                         // const options = {
//                         //     method: 'GET',
//                         //     url: `https://api.opensea.io/api/v1/collection/${item.slug}`,
//                         //     headers: {Accept: 'application/json'}
//                         //     };
                                                    
//                         // axios.request(options).then(function (response) {
//                         //   var name = `${item.name}`;
//                         //   var logo= `${item.logo}`;
//                         //   var slug= `${item.slug}`;
//                         //   var background_image	=`${response.data['collection']['banner_image_url']}`;
                          
//                         //   var contract	=`${response.data['collection']['primary_asset_contracts'][0]['address']}`;
//                         //   var discord_url=`${response.data['collection']['discord_url']}`;
//                         //   var	external_url=`${response.data['collection']['primary_asset_contracts'][0]['external_link']}`;
//                         //   var twitter_username=`${response.data['collection']['twitter_username']}`;
//                         //   var	instagram_username	=`${response.data['collection']['instagram_username']}`;
//                         //   var one_day_volume=`${response.data['collection']['stats']['one_day_volume']}` ;
//                         //   var one_day_change=`${response.data['collection']['stats']['one_day_change']}` ;
//                         //   var one_day_sales= `${response.data['collection']['stats']['one_day_sales']}`;
//                         //   var one_day_average_price=`${response.data['collection']['stats']['one_day_average_price']}`;
//                         //   var seven_day_volume=`${response.data['collection']['stats']['seven_day_volume']}` ;
//                         //   var seven_day_change=`${response.data['collection']['stats']['seven_day_change']}` ;
//                         //   var seven_day_sales=`${response.data['collection']['stats']['seven_day_sales']}` ;
//                         //   var seven_day_average_price=`${response.data['collection']['stats']['seven_day_average_price']}` ;
//                         //   var thirty_day_volume= `${response.data['collection']['stats']['thirty_day_volume']}`;
//                         //   var thirty_day_change= `${response.data['collection']['stats']['thirty_day_change']}`;
//                         //   var thirty_day_sales= `${response.data['collection']['stats']['thirty_day_sales']}`;
//                         //   var thirty_day_average_price= `${response.data['collection']['stats']['thirty_day_average_price']}`;
//                         //   var total_volume= `${response.data['collection']['stats']['total_volume']}`;
//                         //   var total_sales=`${response.data['collection']['stats']['total_sales']}` ;
//                         //   var total_supply= `${response.data['collection']['stats']['total_supply']}`;
//                         //   var count= `${response.data['collection']['stats']['count']}`;
//                         //   var num_owners=`${response.data['collection']['stats']['num_owners']}` ;
//                         //   var average_price= `${response.data['collection']['stats']['average_price']}`;
//                         //   var num_reports= `${response.data['collection']['stats']['num_reports']}`;
//                         //   var market_cap= `${response.data['collection']['stats']['market_cap']}`;
//                         //   var floor_price=`${response.data['collection']['stats']['floor_price']}` ;
                          
//                         //     var sql = `INSERT IGNORE INTO nft_stat5 (name,logo,slug,background_image,contract,discord_url,external_url,twitter_username,instagram_username	,one_day_volume,one_day_change,one_day_sales,one_day_average_price,seven_day_volume,seven_day_change,seven_day_sales,seven_day_average_price,thirty_day_volume,thirty_day_change,thirty_day_sales,thirty_day_average_price,total_volume,total_sales,total_supply,count,num_owners,average_price,num_reports,market_cap,floor_price) VALUES ("${name}","${logo}","${slug}","${background_image}","${contract}","${discord_url}","${external_url}","${twitter_username}","${instagram_username}","${one_day_volume}","${one_day_change}","${one_day_sales}","${one_day_average_price}","${seven_day_volume}","${seven_day_change}","${seven_day_sales}","${seven_day_average_price}","${thirty_day_volume}","${thirty_day_change}","${thirty_day_sales}","${thirty_day_average_price}","${total_volume}","${total_sales}","${total_supply}","${count}","${num_owners}","${average_price}","${num_reports}","${market_cap}","${floor_price}") ON DUPLICATE KEY UPDATE name="${name}",logo="${logo}",slug="${slug}",one_day_volume="${one_day_volume}",one_day_change="${one_day_change}",one_day_sales="${one_day_sales}",one_day_average_price="${one_day_average_price}",seven_day_volume="${seven_day_volume}",seven_day_change="${seven_day_change}",seven_day_sales="${seven_day_sales}",seven_day_average_price="${seven_day_average_price}",thirty_day_volume="${thirty_day_volume}",thirty_day_change="${thirty_day_change}",thirty_day_sales="${thirty_day_sales}",thirty_day_average_price="${thirty_day_average_price}",total_volume="${total_volume}",total_sales="${total_sales}",total_supply="${total_supply}",count="${count}",num_owners="${num_owners}",average_price="${average_price}",num_reports="${num_reports}",market_cap="${market_cap}",floor_price="${floor_price}"`;
//                         //     con.query(sql, function (err, result) {
//                         //         if (err) throw err;
//                         //         console.log(" Data added.");
//                         //     });
//                         // }).catch(function (error) {
//                         //     console.error(error);
//                         // });
                                                        
//                     });
//                 })
//          },6000)
//         }
       
        
//     }
// })

const express = require('express');
const app = express();
// // const axios = require("axios").default;

// app.get("/hello",(req,res)=>{
//   const options = {
//         method: 'GET',
//         url:`https://api.opensea.io/api/v1/assets?collection_slug=azuki&order_direction=desc&limit=20&include_orders=false`,
//         headers: {Accept: 'application/json', 'X-API-KEY': '7369ed7fd1c148e29856e23a2de9d997'}
//       };
      
//       axios.request(options).then(function (response) {
//         response.data.forEach(a=>{
//          console.log(a)
//   })
//         res.send(response.data);
//       }).catch(function (error) {
//         console.error(error);
//       });
// })
var sql = "SELECT COUNT(*) FROM nft_collections";
  
  con.query(sql, (error, results) => {
    if (error) {
      // console.log(error);
      
    }  else {

        var a=((results[0]['COUNT(*)'])/100).toFixed(0)
        console.log(a);
        for(i=1;i<=a;i++)
        {
        const v=i;
        console.log('a',v);
        const b=(v-1)*100;
        const c=v*100;
        console.log(` a ${b}-${c}`)
        setTimeout(()=>{
            // console.log('b',v);
            console.log(` b ${b}-${c}`)
            
            var sql1 = `SELECT name,slug,logo FROM nft_collections LIMIT ${b},100`;
                con.query(sql1, function (err, result) {
                    if (err) throw err;
                    result.forEach(async (item)=>{
                        // console.log(item.slug)
                        const options = {
                            method: 'GET',
                            url: `https://api.opensea.io/api/v1/collection/${item.slug}`,
                            headers: {Accept: 'application/json'}
                            };
                                                    
                        axios.request(options).then(function (response) {
                          var name = `${item.name}`;
                          var logo= `${item.logo}`;
                          var slug= `${item.slug}`;
                          var background_image	=`${response.data['collection']['banner_image_url']}`;
                          
                          var contract	=`${response.data['collection']['primary_asset_contracts'][0]['address']}`;
                          var discord_url=`${response.data['collection']['discord_url']}`;
                          var	external_url=`${response.data['collection']['primary_asset_contracts'][0]['external_link']}`;
                          var twitter_username=`${response.data['collection']['twitter_username']}`;
                          var	instagram_username	=`${response.data['collection']['instagram_username']}`;
                          var one_day_volume=`${response.data['collection']['stats']['one_day_volume']}` ;
                          var one_day_change=`${response.data['collection']['stats']['one_day_change']}` ;
                          var one_day_sales= `${response.data['collection']['stats']['one_day_sales']}`;
                          var one_day_average_price=`${response.data['collection']['stats']['one_day_average_price']}`;
                          var seven_day_volume=`${response.data['collection']['stats']['seven_day_volume']}` ;
                          var seven_day_change=`${response.data['collection']['stats']['seven_day_change']}` ;
                          var seven_day_sales=`${response.data['collection']['stats']['seven_day_sales']}` ;
                          var seven_day_average_price=`${response.data['collection']['stats']['seven_day_average_price']}` ;
                          var thirty_day_volume= `${response.data['collection']['stats']['thirty_day_volume']}`;
                          var thirty_day_change= `${response.data['collection']['stats']['thirty_day_change']}`;
                          var thirty_day_sales= `${response.data['collection']['stats']['thirty_day_sales']}`;
                          var thirty_day_average_price= `${response.data['collection']['stats']['thirty_day_average_price']}`;
                          var total_volume= `${response.data['collection']['stats']['total_volume']}`;
                          var total_sales=`${response.data['collection']['stats']['total_sales']}` ;
                          var total_supply= `${response.data['collection']['stats']['total_supply']}`;
                          var count= `${response.data['collection']['stats']['count']}`;
                          var num_owners=`${response.data['collection']['stats']['num_owners']}` ;
                          var average_price= `${response.data['collection']['stats']['average_price']}`;
                          var num_reports= `${response.data['collection']['stats']['num_reports']}`;
                          var market_cap= `${response.data['collection']['stats']['market_cap']}`;
                          var floor_price=`${response.data['collection']['stats']['floor_price']}` ;
                          
                            var sql = `INSERT IGNORE INTO nft_stats (name,logo,slug,background_image,contract,discord_url,external_url,twitter_username,instagram_username	,one_day_volume,one_day_change,one_day_sales,one_day_average_price,seven_day_volume,seven_day_change,seven_day_sales,seven_day_average_price,thirty_day_volume,thirty_day_change,thirty_day_sales,thirty_day_average_price,total_volume,total_sales,total_supply,count,num_owners,average_price,num_reports,market_cap,floor_price) VALUES ("${name}","${logo}","${slug}","${background_image}","${contract}","${discord_url}","${external_url}","${twitter_username}","${instagram_username}","${one_day_volume}","${one_day_change}","${one_day_sales}","${one_day_average_price}","${seven_day_volume}","${seven_day_change}","${seven_day_sales}","${seven_day_average_price}","${thirty_day_volume}","${thirty_day_change}","${thirty_day_sales}","${thirty_day_average_price}","${total_volume}","${total_sales}","${total_supply}","${count}","${num_owners}","${average_price}","${num_reports}","${market_cap}","${floor_price}") ON DUPLICATE KEY UPDATE name="${name}",logo="${logo}",slug="${slug}",one_day_volume="${one_day_volume}",one_day_change="${one_day_change}",one_day_sales="${one_day_sales}",one_day_average_price="${one_day_average_price}",seven_day_volume="${seven_day_volume}",seven_day_change="${seven_day_change}",seven_day_sales="${seven_day_sales}",seven_day_average_price="${seven_day_average_price}",thirty_day_volume="${thirty_day_volume}",thirty_day_change="${thirty_day_change}",thirty_day_sales="${thirty_day_sales}",thirty_day_average_price="${thirty_day_average_price}",total_volume="${total_volume}",total_sales="${total_sales}",total_supply="${total_supply}",count="${count}",num_owners="${num_owners}",average_price="${average_price}",num_reports="${num_reports}",market_cap="${market_cap}",floor_price="${floor_price}"`;
                            con.query(sql, function (err, result) {
                                if (err) throw err;
                                console.log(" Data added.");
                            });
                        }).catch(function (error) {
                            // console.error(error);
                        });
                                                        
                    });
                })
         },65000*v)
        }
        // console.log("Finished.")
        
    }
})

app.listen(5000,()=>{
    console.log('listening on 5000')
})